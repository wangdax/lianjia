DBENGINE = 'mysql'  # ENGINE OPTIONS: mysql, sqlite3, postgresql
DBNAME = 'ershoufang'
DBUSER = 'root'
DBPASSWORD = ''
DBHOST = '127.0.0.1'
DBPORT = 3306
CITY = 'bj'  # only one, shanghai=sh shenzhen=sh......
REGIONLIST = [u'dongcheng']  # only pinyin support
